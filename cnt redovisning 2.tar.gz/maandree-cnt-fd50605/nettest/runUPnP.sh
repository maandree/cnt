java -cp .:..:../cnt/nettest:cling-core-1.0.5.jar:cling-support-1.0.5.jar:teleal-common-1.0.13.jar nettest.UPnP
