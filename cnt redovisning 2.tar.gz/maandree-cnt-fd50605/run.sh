java7 -ea -cp bin cnt.Program
